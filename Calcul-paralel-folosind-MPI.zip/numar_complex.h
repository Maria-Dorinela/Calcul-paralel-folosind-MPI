
typedef struct nr_complex{

	float re;
	float im;
	
}nr_complex;

//creaza un numar complex
nr_complex creare(float nr1, float nr2);

//adunarea a a doua numere complexe
nr_complex adunare(nr_complex n1, nr_complex n2);

//inmultirea a doua numere complexe
nr_complex inmultire(nr_complex n1, nr_complex n2);

//modulul unui numar complex
float modul(nr_complex nr);

