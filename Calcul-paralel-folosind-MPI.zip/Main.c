#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "mpi.h"
#include "numar_complex.h"
#define NUM_COLORS 256
#define MSG_LEN 13

//functie care creeaza un numar complex
nr_complex creare(float nr1, float nr2){

	nr_complex z;//rezultatul
	
	z.re = nr1;//partea reala
	z.im = nr2;//partea imaginara
	
	return z;//returnez numarul complex creat
}

//functie care face adunarea a doua numere complexe
nr_complex adunare(nr_complex nr1, nr_complex nr2){

	nr_complex rezultat;//rezultatul
	
	rezultat.re = nr1.re + nr2.re;//partea reala a numarului complex
	rezultat.im = nr1.im + nr2.im;//partea imaginara a numarului complex

	return rezultat;//returnez suma a doua numere complexe
}

//functie care face inmultirea a doua numere complexe
nr_complex inmultire(nr_complex nr1, nr_complex nr2){

	nr_complex rezultat;//rezultatul
	
	rezultat.re = nr1.re * nr2.re - nr1.im * nr2.im;//partea reala a numarului complex
	rezultat.im = nr1.re * nr2.im + nr1.im * nr2.re;//partea imaginara a numarului complex
	
	return rezultat;//returnez produsul a doua numere complexe

}

//functie care calculeaza modulul unui numar complex
float modul(nr_complex z){
	
	float rezultat;//rezultatul
	
	rezultat = (z.re * z.re + z.im * z.im);//calculul modulului numarului complex primit ca parametru
	
	return rezultat;//returnez modulul numarului complex primit ca parametru
}

//functia specifica Algoritmului Mandelbrot
int Mandelbrot(float x_min, float y_min, float rezolutie, int i, int j, int max_steps){

	nr_complex z,c;//numere complexe
	int step,rezultat;//pasul si rezultatul obtinut
	z = creare(0,0);//initializare z
	c = creare(x_min + j * rezolutie, y_min + i * rezolutie);//initializare c
	step = 0;//initializare step
	while((modul(z) < 4) && (step < max_steps)){
		nr_complex m = inmultire(z,z);
		z = adunare(m, c);
		step = step + 1;
	}

	rezultat = step % NUM_COLORS;
	return rezultat;
}

//functia specifica Algoritmului Julia
int Julia(float x_min, float y_min, float rezolutie, float julia1, float julia2, int i, int j, int max_steps){

	nr_complex z,c;//numere complexe
	int step, rezultat;//pasul si rezultatul obtinut
	
	z = creare(x_min + j * rezolutie, y_min + i * rezolutie);//initializare z
	c = creare(julia1, julia2);//initializare c
	step = 0;//initializare step

	while((modul(z) < 4) && (step < max_steps)){

		nr_complex m = inmultire(z,z);
		z = adunare(m, c);
		step = step + 1;
		
	}
	rezultat = step % NUM_COLORS;
	return rezultat;
}

int main(int argc, char *argv[]){

	FILE *file_in, *file_out; //fisierul de intrare respectiv iesire
	file_in = fopen(argv[1], "r");//deschid fisierul de intrare pentru citire(primul parametru)
	
	float vector[4];
	float parametru_complex[2];
	int i,j,k;
	float x,y;
	char* nume_file_out;
	
	int tip_multime; //prima linie din fisierul de intrare
	float x_min, x_max, y_min, y_max; //subspatii din planul complex
	float rezolutia;//rezolutia
	int MAX_STEPS;//numarul maxim de pasi
	float parametru_complex1 = 0.0, parametru_complex2 = 0.0; //pentru calcului mulțimii Julia
	
	int width, height;//dimensiunile matrici de iesire
	int lll = 0;
	int num_tasks, rank, size;
	MPI_Status status;
	
	
	 // initializari
	MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &num_tasks);
    	
   if(rank == 0){
	fscanf(file_in,"%i",&tip_multime);//citesc prima linie din fisier care defineste tipul de multime care va fi generata

	 
	 for(i = 0; i < 4; i++){//initializare vector coordonate
		vector[i] = 0.0;
	 }
	
	for(i = 0; i < 2; i++){//initializare vector parametri pentru julia
		parametru_complex[i] = 0.0;
	}
	
	for(i = 0; i < 4; i++){
		fscanf(file_in,"%f",&x);//citesc coordonatele si le bag in vectorul "vector"
		vector[i] = x;	
	}
	x_min = vector[0];
	x_max = vector[1];
	y_min = vector[2];
	y_max = vector[3];
	
	
	fscanf(file_in,"%f",&rezolutia);//citesc rezolutia
	fscanf(file_in,"%i",&MAX_STEPS);//citesc numarul maxim de pasi
	
	if(tip_multime == 1){//citesc parametri pentru julia
		for(i = 0; i < 2; i++){
			fscanf(file_in,"%f",&y);
			parametru_complex[i] = y;	
		}
		parametru_complex1 = parametru_complex[0];
		parametru_complex2 = parametru_complex[1];	
	}
	else{
		parametru_complex1 = 0.0;
		parametru_complex2 = 0.0;
	}
	
	fclose(file_in);//inchide fisier
	
	//calcul numar de linii si coloane ale matricii
	 width = (x_max - x_min)/rezolutia;
	 height = (y_max - y_min)/rezolutia;

	int de_calculat = height / num_tasks;//numarul de linii e care le are fiecare proces de calculat
	
	int a;
	int **matrice;//matrice de iesire
	matrice = malloc(height * sizeof(int*));//alocare memorie pemtru matrice
	for(a = 0; a < height; a++)
		matrice[a] = malloc(width * sizeof(int));

	float date_trimise[MSG_LEN];//vector cu datele pe care procesul 0 le trimite fiecarui proces
	int i1, i2;
 	int date_receptionate[width+1];//vector cu date pe care procesul 0 le receptioneaza de la fiecare proces(linia din matrice pe care a calculat-o)
	int contor = 0;

	//procesul 0 va calcula primele de_calculat linii, dupa care trimite la celelelte procese restul
	 if(tip_multime == 1){//aplic Julia

		for(i1 = 0; i1 <= de_calculat - 1; i1++){

			for(i2 = 0; i2 < width; i2++){

					matrice[i1][i2] = Julia(x_min, y_min, rezolutia, parametru_complex1, parametru_complex2, i1, i2, MAX_STEPS);
		
				}

			}

		}
	else if(tip_multime == 0){//aplic Mandelbrot
			
			for(i1 = 0; i1 <= de_calculat - 1; i1++){
				
				for(i2 = 0; i2 < width-1; i2++){
					
					matrice[i1][i2] = Mandelbrot(x_min, y_min, rezolutia, i1, i2, MAX_STEPS);
					
				}

			}

		}
	
		for(i = 1; i < num_tasks; i++){

			//datele pe care le trimit fiecarui proces
			int start_line = i * de_calculat;
			int stop_line = i * de_calculat + (de_calculat - 1);
			date_trimise[0] = tip_multime;
			date_trimise[1] = x_min;
			date_trimise[2] = x_max;
			date_trimise[3] = y_min;
			date_trimise[4] = y_max;
			date_trimise[5] = rezolutia;
			date_trimise[6] = MAX_STEPS;
			date_trimise[7] = parametru_complex1;
			date_trimise[8] = parametru_complex2;
			date_trimise[9] = width;
			date_trimise[10] = height;
			date_trimise[11] = start_line;
			date_trimise[12] = stop_line;

			MPI_Send(&date_trimise,MSG_LEN, MPI_FLOAT,i,1,MPI_COMM_WORLD);

		}

	 int f1, f2, first = 0, dd = 0;
		
	//procesul 0 primeste de la celelelte procese ce au calculat ci completeaza matricea
	 for(f1 = 0; f1 < height - de_calculat; f1++){
		
		MPI_Recv(&date_receptionate, width + 1, MPI_INT, MPI_ANY_SOURCE, 2, MPI_COMM_WORLD, &status);
		
		first = date_receptionate[0];//primul element din vector este linia din matrice pentru care a calculat acel proces de lacare a primit
		
		for(f2 = 0; f2 < width; f2++){

			matrice[first][f2] = date_receptionate[f2+1];
			
		}
		
	 }


	file_out = fopen(argv[2], "w");//deschidere fisier pentru scriere rezultat final
	
	fprintf(file_out, "%s\n", "P2");
	fprintf(file_out, "%d %d\n", width, height);
	fprintf(file_out, "%d\n", NUM_COLORS - 1);

	//parcurgerematrice si scrierea ei in fisier	
	for(i = 0; i < height; i++){

		for(j = 0; j < width; j++){

				fprintf(file_out, "%i ", matrice[height - i - 1][j]);
	
		}

		fprintf(file_out, "\n");

	}
	
	fclose(file_out);//inchidere fisier


   }
   else{//daca nu este procesul 0

		float date_primite[12];//vector in care fiecare proces va primi datele de la procesul 0
 
		MPI_Recv(&date_primite,MSG_LEN, MPI_DOUBLE, 0, 1,MPI_COMM_WORLD, &status);//primire date de la proces 0

		int type = date_primite[0];
		float x_m = date_primite[1];
		float x_M = date_primite[2];
		float y_m = date_primite[3];
		float y_M = date_primite[4];
		float r = date_primite[5];
		int m_s = date_primite[6];
		float j1 = date_primite[7];
		float j2 = date_primite[8];
		int w = date_primite[9];
		int h = date_primite[10];
		int start = date_primite[11];
		int end = date_primite[12];
		int p1, p2;
		int date_finale[w+1];
	
		//daca au mai ramas linii, le va calcula ultimul proces
		int dori = h % num_tasks;
		if ((rank == num_tasks-1) && (dori != 0)) {
	
			end = end + dori;
			
    	}
		
		if(type == 1){//aplic Julia

			for(p1 = start; p1 <= end; p1++){

				date_finale[0] = p1;

				for(p2 = 0; p2 < w; p2++){
				
					date_finale[p2 + 1] = Julia(x_m, y_m, r, j1, j2, p1, p2, m_s);
					
				}

			 MPI_Send(&date_finale, w + 1, MPI_INT, 0, 2, MPI_COMM_WORLD);//trimitere rezultat la proces 0

			 }
		}

		else if(type == 0){//aplic Mandelbrot

			for(p1 = start; p1 <= end; p1++){

				date_finale[0] = p1;

				for(p2 = 0; p2 < w-1; p2++){

					date_finale[p2 + 1] = Mandelbrot(x_m, y_m, r, p1, p2, m_s);
					
				}

			 MPI_Send(&date_finale, w + 1, MPI_INT, 0, 2, MPI_COMM_WORLD);//trimitere rezultat la proces 0

			 }

		}
	

    }
	
	MPI_Finalize();
	
}




